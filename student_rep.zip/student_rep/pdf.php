
<?php include "user/config.php"; 

header('Content-Type: text/html;charset=utf-8'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html>
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">
 <title>Word Document</title>
  <link rel="stylesheet" href="..\css/schoolcollege.css">


 <head>
 <style>
 button
 {
   border-radius: 1em;
   padding: 1em;
 background-color: lightred;
 font-size: 1em;

 }
 fieldset{
	 width:100%;
	
	 
 }
 tr,td{
	 text-align:left;
	 line-spaceing:10px;
	}
 fieldset {
   -webkit-border-radius:11px;
   -moz-border-radius:11px;
   border-radius:11px;
 }
 span{
	 color:blue;
	  spaceing:10px;
 }
 div.position {
    width: 80%;
   
  border: 3px solid #73AD21;
}

 </style>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
 <script>
 function Export2Doc(element, filename = ''){
    var preHtml = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Export HTML To Doc</title></head><body>";
    var postHtml = "</body></html>";
    var html = preHtml+document.getElementById(element).innerHTML+postHtml;

    var blob = new Blob(['\ufeff', html], {
        type: 'application/msword'
    });

    // Specify link url
    var url = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(html);

    // Specify file name
    filename = filename?filename+'.doc':'document.doc';

    // Create download link element
    var downloadLink = document.createElement("a");

    document.body.appendChild(downloadLink);

    if(navigator.msSaveOrOpenBlob ){
        navigator.msSaveOrOpenBlob(blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = url;

        // Setting the file name
        downloadLink.download = filename;

        //triggering the function
        downloadLink.click();
    }

    document.body.removeChild(downloadLink);
}
</script>

</head>
<body>


<form method="post">

 <div id="exportContent">
<?php
$yesorno=array("ஆம்","இல்லை");
$rec_id =  $_GET['id'];
$sql="select * from studend_sales_rep.student_rep_details_ht where id='{$rec_id}'";
$res=$con->query($sql);
if($res->num_rows>0){
   while($row=$res->fetch_assoc()){

?>
<?php
 echo "
 
 <center>
  <img src='https://tamil.thehindu.com/static/theme/default/base/img/newIpadLogo.png'  height='100' align='center'></center>
<center>



    <b><u><label>மாணவர் விற்பனைப் பிரதிநிதிகள் பயிற்சித் திட்டம் விண்ணப்பப்  படிவம்</label></u></b></center><br><fieldset>
 <center>
 
<table border='0'>
<tr><td><span style='font-size:1em'><b>Application Number:</b></span></td><td><b>".$row['Application_id']."</b></td></tr>
<tr><td><label style='background-color:orange'><b><legent>Personal details</legent></b></label></td></tr>
 <tr><td width='80%'><span>1.</span>உங்கள் பெயர் :</td><td>".$row['std_name']."</td></tr>
 <tr><td><span>2.</span>தாய்மொழி :</td><td>".$row['Language']."</td></tr>
 
 <tr><td><span>3.</span>தந்தையார் / காப்பாளர் பெயர் :</td><td>".$row['Father_name']."</td></tr>
 <tr><td><span>4.</span>தந்தையார் / காப்பாளரின் வேலை பற்றிய விவரம் :</td><td>".$row['Father_occupattion']."</td></tr>
 <tr><td><span>5.</span>பிறந்த தேதி :</td><td>".$row['DOB']."</td></tr>
 <tr><td><span>6.</span>உங்கள் முழு விலாசம் :</td><td>".$row['Address']."</td></tr>
 <tr><td><span>7.</span>மாவட்டம் :</td><td>".$row['District']."</td></tr>
 <tr><td><span>8.</span>பின்கோடு :</td><td>".$row['pincode']."</td></tr>
 <tr><td><span>9.</span>செல்பேசி எண் :</td><td>".$row['mobile']."</td></tr>
 <tr><td><span>10.</span>மின்னஞ்சல்  :</td><td>".$row['email']."</td></tr>
 <tr><td><span>11.</span>கல்லூரியின் பெயர் :</td><td>".$row['College_name']."</td></tr>
 <tr><td><span>12.</span>கல்லூரியின் முகவரி  :</td><td>".$row['college_Address']."</td></tr>
 <tr><td><span>13.</span>கல்லூரியின் பின்கோடு  :</td><td>".$row['college_pincode']."</td></tr>
 <tr><td><span>14.</span>என்ன படிக்கிறீர்கள்  :</td><td>".$row['Stud_dep']."</td></tr>
 <tr><td><span>15.</span>எத்தனையாவது ஆண்டு   :</td><td>".$row['student_year']."</td></tr>
 <tr><td><span>16.</span>வங்கியின்  பெயர்  :</td><td>".$row['Bank_name']."</td></tr>
 <tr><td><span>17.</span>வங்கிக் கிளை  :</td><td>".$row['Account_no']."</td></tr>
 <tr><td><span>18.</span>IFSC Code  :</td><td>".$row['Branch']."</td></tr>
 <tr><td><span>19.</span>Account No  :</td><td>".$row['IFSC_code']."</td></tr>
 <tr><td><span>20.</span>உங்கள் ஆதார் எண் :</td><td>".$row['Adhar_id']."</td></tr>
 <tr><td><label style='background-color:orange'><b>கேள்வி /பதில்</b></label></td></tr>
 <tr><td><span>1.</span>படிக்கும்போதே பகுதி நேரமாக பணியாற்றிய அனுபவம் இதற்குமுன் உண்டா ?  :</td><td>".$yesorno[$row['question_1']]."</td></tr>
 <tr><td>‘ஆம்’ என்றால் அதுபற்றிய விவரம் சுருக்கமாக :</td><td>".$row['Answer_1']."</td></tr>
 <tr><td><span>2.</span>பத்திரிகை / இணையதளத்தில் ஏதேனும் கதை /கவிதை /கட்டுரை எழுதிய அனுபவம் உண்டா ?  :</td><td>".$yesorno[$row['Qustion_2']]."</td></tr>
 <tr><td>'ஆம்’ என்றால் அது பற்றிய விவரம்  :</td><td>".$row['Answer_2']."</td></tr>
 <tr><td><span>3.</span>பேச்சுப் போட்டி , கலை  நிழச்சி உள்ளிட்ட மற்ற திறமைகளை வெளிப்படுத்தும் நிகழ்வுகளில் கலந்து கொண்ட அனுபவம் உண்டா ?  :</td><td>".$yesorno[$row['Question_3']]."</td></tr>
 <tr><td>‘ஆம்’ எனில் அதுபற்றிய விவரம்  :</td><td>".$row['Answer_3']."</td></tr>
 <tr><td><span>4.</span>உங்களின் காலை முதல் இரவு வரையிலான அன்றாடப் பணிகளை சுருக்கமாக வரிசைப்படுத்துங்கள் :</td><td>".$row['Answer_4']."</td></tr>
 <tr><td><span>5.</span>நீங்கள் சொந்தமாக  வாகனம் வைத்திருக்கிறீர்களா?  :</td><td>".$yesorno[$row['Question_5']]."</td></tr>
 <tr><td>‘ஆம்’ எனில், வாகன எண்/ உங்கள் ஓட்டுநர் உரிம எண் :</td><td>".$row['Answer_5']."</td></tr>
 <tr><td><span>6.</span>உங்கள் குடும்பத் தில் அரசியல் கட்சி உறுப்பினர் எவரும் உண்டா ?  :</td><td>".$yesorno[$row['Question_6']]."</td></tr>
 <tr><td>‘ஆம்’ எனில் விவரம் :</td><td>".$row['Answer_6']."</td></tr>
 <tr><td><span>7.</span>உங்கள் உறவினர் எவரும் பத்திரிகைத் துறையில் பணி புரிகிறார்களா?  :</td><td>".$yesorno[$row['Question_7']]."</td></tr>
 <tr><td>‘ஆம்’ எனில் விவரம்  :</td><td>".$row['Answer_7']."</td></tr>

</table>
</center><br>
<div class='row'>
 <div class='col-sm-12'>
<label><font color='blue'>கல்லூரி நிர்வாகத்தின் ஒப்புதல்: </font>கீழ்கண்டவாறு உங்கள் கல்லூரி முதல்வர் / தாளாளர் கையொப்பமும்  , கல்லூரியின்
முத்திரையும் கூடிய ஒப்புதல் கடிதம் பெறவேண்டியது அவசியம். நீங்கள் ஜூலை-21 அன்று நடை பெறும் எழுத்துத் தேர்வுக்கு
தேர்ந்தெடுக்கப்பட்டால் அந்த கடிதத்தை கட்டாயம் கொண்டுவரவும் .</label>
<label>எங்கள் கல்லூரியில் __________________________________________________ வகுப்பு  _____________________________________ ஆண்டு பயிலும் 
மாணவர் செல்வன் / செல்வி  ______________________________________________‘இந்து தமிழ் திசை ’ நாளிதழ் அளிக்கும் இந்தத் திட்டத்தின் கீழ், கல்லூரிப்
   படிப்பைத் தொடர்ந்து கொண்டே பகுதி நேரமாகப் பயிற்சி
பெறுவதில், எந்த ஆட்சேபணையும் இல்லை.</label><br><br><br><br><br><label>
கல்லூரி முதல்வர்/ தாளாளர் கையொப்பம்    (முத்திரையுடன்) </label><br><br><br>

<label><font color='red'><center>
எழுத்துத் தேர்வுக்கு தேர்ந்தெடுக்கப்பட்டால் உங்கள் மார்பளவு பாஸ்போர்ட் சைஸ் புகைப்படங்கள் இரண்டு மற்றும் விண்ணப்ப படிவத்தின் நகலை தவறாமல் கொண்டுவரவும்.
<br>கல்லூரி நிர்வாகத்தின் ஒப்புதல் பெறப்பட்ட விண்ணப்ப படிவம் மட்டுமே தேர்வுசெய்யப்படும்.</center></font></div></fieldset>";
}
}  
?>

</form>
</div>
  
<center>
 
<br>
       <button onclick="Export2Doc('exportContent', 'word-content');document.location.href='index.php'">கல்லூரி நிர்வாகத்தின் ஒப்புதல் பெற விண்ணப்ப படிவத்தை இங்கே Download செய்யவும்  </button>
 
 
</center>

</body>
</html>
