<?php
include "user/config.php";
?><?php include "user/header.php" ?>
<style>
tr,td{
	 text-align:left;
	 line-spaceing:10px;
	}
</style>

<?php
if(isset($_POST["submit"]))
{
	$name=$_POST['name'];
	 
	$mobile=$_POST['tel_num'];
	$email=$_POST['email'];
	 
	  $sql1="select count(*) as Count from studend_sales_rep.student_rep_details_ht";
 $result=$con->query($sql1);
  $res1=$result->fetch_assoc();
 if($res1['Count']==0){
	 $appval="SSRCIR40000";
 }
 else if($res1['Count']>0){
 $sql2="select id from studend_sales_rep.student_rep_details_ht order by id desc";
 $result1=$con->query($sql2);
$res2=$result1->fetch_assoc();
 $p=(int)($res2['id'])+1;
  $appval='SSRCIR4000'.$p;
 
 }
 echo "<center>";
  
  echo "<font size='4em'> <b>Application_id : </b>".$appval." <br><br>";
  echo "<b> Name :</b>".$name."<br><br>";
  echo " <b>Mobile :</b>".$mobile."<br><br>";
  echo " <b>Email :</b>".$email."<br><br>";
  
	echo "<b>Application No</b> is mandatory for upload image in this web portal.<br><br><br>";
	echo "<a href='#' class='yourlink'>Click here Download Empty Form</font></a></br>
	<br><a href='index.php'><b>Home</b></a><br><br><br><br><br><br><label>எழுத்துத் தேர்வுக்கு தேர்ந்தெடுக்கப்பட்டால் உங்கள் மார்பளவு பாஸ்போர்ட் சைஸ் புகைப்படங்கள் இரண்டு மற்றும் விண்ணப்ப படிவத்தின் நகலை தவறாமல் கொண்டுவரவும்.</label><br><br>
	<label>போர்டல் சரிபார்ப்புடன் விண்ணப்ப எண் அவசியம். தயவுசெய்து அதைக் கவனியுங்கள், பயன்பாடு இல்லாமல் இந்த போர்டல் மற்றும் சரிபார்ப்பு நோக்கத்தில் உங்கள் படிவத்தை ஏற்க முடியாது.</label>";
	echo"</center>";
	echo"<script>$('a.yourlink').click(function(e) {
    e.preventDefault();
    window.open('/studentrep/pdf/Application Form A4 size_Back.pdf');
    window.open('/studentrep/pdf/Application Form A4 size_Front.pdf');
     
});</script>";
	
$sql="INSERT INTO studend_sales_rep.student_rep_details_ht (Application_id,std_name,mobile,email) VALUES('$appval','$name','$mobile','$email')";
 
//echo $sql;
if ($con->query($sql) === TRUE) {

	
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}
?>
