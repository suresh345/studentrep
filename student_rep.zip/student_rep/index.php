<?php include "user/config.php";?>
 <?php include "user/header.php" ?>
<style>
.responsive1 {
  width: 100%;
  max-width: 1000px;
  height: auto;
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
span{
	cursor: pointer;
}

p{
color:#000000;  /* this is for old browsers */
font-size:18.5px;
font-family:arial;
text-shadow:   0 0 2px #000000,  
1px 0 1px #000000,
cursor: pointer;
}p1{
color:#000000;  /* this is for old browsers */
font-size:18.5px;
font-family:arial;
text-shadow:   0 0 2px #000000,  
1px 0 1px #000000,
cursor: pointer;
}

 
</style>
<div class="container">
  <!-- Trigger the modal with a button -->
 <p1><label><span class="blinking">Pdf வடிவத்தில் விண்ணப்ப படிவத்தை Download செய்துகொள்ள:</span></label></p1><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal">Click Here....</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Verification</h4>
        </div>
		 <form  method="post" action="validate.php" enctype="multipart/form-data">
        <div class="row">
    <div class="col-sm-4">
 <label class="ex">உங்கள் பெயர் :</label>
 <input name="name"  type="text"   class="form-control mandatoryinput borderredcolor" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">செல்பேசி எண் :</label>
<input   type="text" name="tel_num" value=""   minlength=10 maxlength="12" class="form-control phone" autocomplete="off" required></div> 
<div class="col-sm-4">
<label class="ex">மின்னஞ்சல் :</label>
<input   type="email" name="email" value=""   class="form-control phone" autocomplete="off" required></div></div>
        <div class="modal-footer">
		   <button type="submit"  name="submit" onclick="this.form.submit();this.disabled = true;" value="/studentrep/pdf/Application Form A4 size_Back.pdf"  class="btn btn-success btn-lg">Submit</button>
        </div>
		</form> 

      </div>
    </div>
  </div>
  </div><br>
  <a href="upload.php"><p> <label><span class="blinking">கல்லூரி நிர்வாகத்தின் ஒப்புதல் பெறப்பட்ட விண்ணப்ப படிவத்தை இங்கே பதிவேற்றம் செய்யவும்.</span></label></p></a><br>
<center>
<img src='online content New.jpg'   class="responsive1" width="800" height="500" align='center'><br><br><form action="Studform.php">
<input type="checkbox" id="check" name="checkbox" required><font size=4em'><font color="red">மேற்கண்ட விதிமுறைகளை படித்து புரிந்து கொண்டேன்</font><br><br>
 <button name="submit" class="button" onclick="usersubmit();">படிவத்தை பூர்த்திசெய்ய</button> 
</form>
 
</center>
</body>
</html>
 
 