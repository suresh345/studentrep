<?php
$con = new mysqli("127.0.0.1","root","MySQL123","studend_sales_rep");
?>
 