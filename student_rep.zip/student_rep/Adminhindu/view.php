 <?php
include "config.php";
 ?>
 <html>
<head>
 <link rel="stylesheet" href="..\css/schoolcollege.css">

 <style>
 button
 {
   border-radius: 1em;
   padding: 1em;
 background-color: red;
 font-size: 1em;

 }
img { 
           
 
        } 
 fieldset {
   -webkit-border-radius:11px;
   -moz-border-radius:11px;
   border-radius:11px;
 }
 div.position {
    width: 10%;
   
  border: 3px solid #73AD21;
}

 </style>
</head>
<body>
  <center>
  <nav class="navbar navbar-default" >

    <img src="https://tamil.thehindu.com/static/theme/default/base/img/newIpadLogo.png"><br>
</nav>
</center><br>

 <?php 
  $sql1 = "SELECT * FROM studend_sales_rep.image where name='{$_GET["Application_id"]}' ";
  
$res1=$con->query($sql1);
if($res1->num_rows>0) {

   while ($rows=$res1->fetch_assoc()) {

      
     $image=explode('~', rtrim($rows['image'],'~'));

     //what will do here


     echo '<br>';

        echo '<center><hr> ';

        for( $j=0;$j<sizeof($image);$j++)
   {
	    
        echo "<br>
        <img src='http://104.211.96.107/studentrep/image/$image[$j]'  width='50%' height='100%'   id='myimage' position='fixed'/><br>
		<input type='button' id='img'onclick='rotateImage();' name='img' value='click' />
		";
   }
   
   }
}
		?>
		</body>
		</html>
		<script>
		function rotateImage() {
        var img = document.getElementById('myimage');
        img.style.transform = 'rotate(360deg)';
    }
		</script>