<?php
include "config.php";
session_start();
if (empty($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
 ?><br/>
<!DOCTYPE html>
<html> 
<head><title>SSR Details</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- jQuery -->
<script>
$(document).ready(function()
{
  $("#myInput").on("keyup", function() 
  {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() 
	{
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
<script type="text/javascript">
			$(document).ready(function() {
				 
				$("#Agent").select2({
				  data: Agent
				});
			});
		</script>
<link rel="stylesheet" href="admin.css">
<style>
body {
    font-family: Times, Times New Roman, Georgia, serif ,Bamini,'Catamaran', sans-serif;
    color: black;
}
p.log {
  text-align: right;
}
input[type=submit]
{
	background-color:lightblue;
	radius:1em;
	padding:10px;
}
.searchTerm {
  width: 80%;
  border: 3px solid #00B4CC;
  border-right: none;
  padding: 5px;
  height: 50px;
  border-radius: 5px 0 0 5px;
  outline: none;
  color: #9DBFAF;
}
</style>
</head>
<body>
<center>
  <img src='https://tamil.thehindu.com/static/theme/default/base/img/newIpadLogo.png'  height='100' align='center'></center>
<center>
<?php
$showRecordPerPage = 25;
if(isset($_GET['page']) && !empty($_GET['page'])){
$currentPage = $_GET['page'];
}else{
$currentPage = 1;
}
$startFrom = ($currentPage * $showRecordPerPage) - $showRecordPerPage;
$totalEmpSQL ="SELECT * from studend_sales_rep.student_rep_details_ht where id order by id desc" ;
$allEmpResult = mysqli_query($con, $totalEmpSQL);
$totalEmployee = mysqli_num_rows($allEmpResult);
$lastPage = ceil($totalEmployee/$showRecordPerPage);
$firstPage = 1;
$nextPage = $currentPage + 1;
$previousPage = $currentPage - 1;
//$sql = "SELECT *  FROM studend_sales_rep.student_rep_details_ht  where id order by id desc LIMIT $startFrom, $showRecordPerPage";
$sql = "SELECT *,(SELECT name FROM studend_sales_rep.image  x where x.name=y.Application_id) as name FROM studend_sales_rep.student_rep_details_ht y order by id desc LIMIT $startFrom, $showRecordPerPage";
$res=$con->query($sql);
if($res->num_rows>0) {
$i=0;

?>

<a href="logout.php"> 
<p style="text-align:right">LOG OUT</button></p></a>
<table id='customers' class="table-responsive">
<thead>
  <input class="searchTerm" id="myInput" type="text" placeholder="Search.."/>
  <br/><br>
<tr>
<th>S.No</th>
<th>Application No</th>
<th>Student Name</th>
<th>Language</th>
<th>Father Name</th>
<th>Father occupation</th>
<th>Mobile</th>
<th>Email</th>
<th>Date Of Birth</th>
<th>College Name</th>
<th>College Address</th>
<th>College Pincode</th>
<th>Student Department</th>
<th>Student Year</th>	
<th>View</th>
</tr>
</thead>
<tbody>
<?php
while ($rows=$res->fetch_assoc()) {
$i++;
?>
<tbody id="myTable">
<form method="post" action="">
<tr>

<td style='text-align:left;table-layout:fixed;
  width:50px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo   $i; ?></td>
<td style='text-align:left;table-layout:fixed;
  width:150px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['Application_id']; ?></td>
<td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['std_name']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['Language']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:150px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['Father_name']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:150px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['Father_occupattion']; ?></td>
<td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['mobile']; ?></td>
<td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['email']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['DOB']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['College_name']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:150px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['college_Address']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['college_pincode']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['Stud_dep']; ?></td>
  <td  style='text-align:left;table-layout:fixed;
  width:100px;
  overflow:hidden;
  word-wrap:break-word;'><?php echo $rows['student_year']; ?></td>
 
  <?php
 echo "<td font-size= 40px;> <button class='button button4' value='View'><a href='view.php?Application_id={$rows["name"]}'>View</a></button></td>";
?>
</tr>
</form> 
<?php }} ?>
</tbody>
</table>
<nav aria-label="Page navigation">
<ul class="pagination">
<?php if($currentPage != $firstPage) { ?>
<li class="page-item">
<a class="page-link" href="?page=<?php echo $firstPage ?>" tabindex="-1" aria-label="Previous">
<span aria-hidden="true">First</span>
</a>
</li>
<?php } ?>
<?php if($currentPage >= 2) { ?>
<li class="page-item"><a class="page-link" href="?page=<?php echo $previousPage ?>"><?php echo $previousPage ?></a></li>
<?php } ?>
<li class="page-item active"><a class="page-link" href="?page=<?php echo $currentPage ?>"><?php echo $currentPage ?></a></li>
<?php if($currentPage != $lastPage) { ?>
<li class="page-item"><a class="page-link" href="?page=<?php echo $nextPage ?>"><?php echo $nextPage ?></a></li>
<li class="page-item">
<a class="page-link" href="?page=<?php echo $lastPage ?>" aria-label="Next">
<span aria-hidden="true">Last</span>
</a>
</li>
<?php } ?>
</ul>
</nav>
</center>
</body>
</html>