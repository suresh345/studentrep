<?php include "user/config.php";?>
<?php include "user/header.php" ?>
<div class="form-group">
     <div class="container">
	 <form  method="post" action="" enctype="multipart/form-data">
  
  <fieldset><div class="form-group">
  <p><center><b><font color="blue"><h3>மாணவர் விற்பனைப் பிரதிநிதிகள் பயிற்சித் திட்டம் விண்ணப்பப்  படிவம்</h3></font></b></center></p><br><br><br><legend>
   <div class="row">
    <div class="col-sm-4">
 <label class="ex">Application No:</label>
 <input name="name"  type="text"  style="text-transform:uppercase" class="form-control mandatoryinput borderredcolor" autocomplete="off" required></div>
 <div class="col-sm-4">
 <label class="ex">Mobile:</label>
 <input name="mobile"  type="text"   class="form-control mandatoryinput borderredcolor" minlength=10 maxlength="10" autocomplete="off" required></div>
<div class="col-sm-4"><label class="ex">Upload <font color=black>(Image only Accepted)</font> :</label>
<input name="student[]" type="file" id="file" style="padding-left: 2px; padding-right: 2px; padding-top: 3px; padding-bottom: 3px;"accept="image/jpeg,image/jpg,image/x-png,image/x-MS-bmp"  placeholder="pic of"  class="form-control" multiple='' required></div>
</div>
</legend>
</fieldset>
<center><button type="submit"  name="submit"   class="btn btn-success btn-lg">Submit</button></center>
</form>
</div>
</div>
<?php

if(isset($_POST["submit"]))
{

$name=strtoupper($_POST['name']);
	$mobile=$_POST['mobile'];
	 
 
$targetDir = "image/";
          $rnd=rand(100,999);
           $rnd=$rnd."_";
        $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
        if(!empty(array_filter($_FILES['student']['name']))){
            foreach($_FILES['student']['name'] as $key=>$val){
                // File upload path
                $fileName =$rnd.$name."_".basename($_FILES['student']['name'][$key]);
                $targetFilePath = $targetDir . $fileName;

                // Check whether file type is valid
                $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
                
                    // Upload file to server
                    if(move_uploaded_file($_FILES["student"]["tmp_name"][$key], $targetFilePath)){
                        // Image db insert sql
                        $insertValuesSQL .= "$fileName~";

                    }else{
                        $errorUpload .= $_FILES['student']['name'][$key].', ';
                    }
                 
            }


        }
		else
		{
			echo "Image cannot be upload";
		}
 
        
   
 
 $sql="insert into studend_sales_rep.image(name,mobile,image) values ('$name','$mobile','$insertValuesSQL')";
 //echo $sql;
 if ($con->query($sql) === TRUE) {
 echo "<script>
  alert('Thanks for your Submission');
  window.location.href='upload.php';
  </script>";
	
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
}

?>