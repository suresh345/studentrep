﻿<?php include "user/config.php";?>
<?php include "user/header.php" ?>
<style>
 

</style>

 
 <div class="form-group">
     <div class="container">
	   
	 <?php include "user/guidliness.php" ?>
	 <form  method="post" action="" enctype="multipart/form-data">
   <label><font color="red">ஆன்லைன் மூலமாக விண்ணப்ப படிவத்தை பூர்த்தி செய்ய.</font></label>
 <fieldset><div class="form-group">
  <div class="row">
  <div class="col-sm-15">
  <center><b><font color="black"><label style="font-size:20px">மாணவர் விற்பனைப் பிரதிநிதிகள் பயிற்சித் திட்டம் விண்ணப்பப்  படிவம்.</label></font></b></center></div></div><br>
   <div class="row">
    <div class="col-sm-4">
 <label class="ex">உங்கள் பெயர் :</label>
 <input name="name"  type="text"   class="form-control mandatoryinput borderredcolor" autocomplete="off" required></div>
<div class="col-sm-4"><label class="ex">தாய்மொழி :</label>
<input  type="text"   class="form-control" autocomplete="off" name="lang"required></div>
<div class="col-sm-4">
<span></span>
<label class="ex">தந்தையார் / காப்பாளர் பெயர் :</label>
<input   type="text" name="fname" value=""   class="form-control phone" autocomplete="off" required></div>
<div class="col-sm-5">
<label class="ex">தந்தையார் / காப்பாளரின் வேலை பற்றிய விவரம் :</label>
<input  type="text" name="fwork" value=""   class="form-control phone" autocomplete="off" required></div>
<div class="col-sm-3">
<label class="ex">பிறந்த தேதி:</label>
<input   type="date" name="dob" value=""   class="form-control phone" autocomplete="off" required></div>

 <div class="col-sm-4">
<label>உங்கள் முழு விலாசம் :</label>
<input   type="text" name="address" value=""   class="form-control phone" autocomplete="off" required></div>
  <div class="col-sm-4">
<label class="ex">மாவட்டம் :</label>
<input   type="text" name="dis" value=""   class="form-control phone" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">பின்கோடு :</label>
<input   type="text" name="pincode" value=""  minlength=6 maxlength="6" class="form-control phone" autocomplete="off" required></div>
  <div class="col-sm-4">
<label class="ex">செல்பேசி எண் :</label>
<input   type="text" name="tel_num" value=""   minlength=10 maxlength="12" class="form-control phone" autocomplete="off" required></div> 
<div class="col-sm-4">
<label class="ex">மின்னஞ்சல் :</label>
<input   type="email" name="email" value=""   class="form-control phone" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">கல்லூரியின் பெயர்:</label>
<input   type="text" name="c_name" value=""   class="form-control phone" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">முகவரி :</label>
<input   type="text" name="c_address" value=""   class="form-control phone" autocomplete="off" required></div>
  <div class="col-sm-4">
<label class="ex">கல்லூரியின் பின்கோடு :</label>
<input   type="text" name="c_pincode" value="" minlength=6 maxlength="6"  class="form-control phone" autocomplete="off" required></div>
  <div class="col-sm-4">
<label class="ex">என்ன படிக்கிறீர்கள் :</label>
<input   type="text" name="dep" value=""   class="form-control phone" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">எத்தனையாவது ஆண்டு :</label>
<input   type="text" name="year" value=""   class="form-control phone" autocomplete="off" required></div>
 <div class="col-sm-4">
<label class="ex">வங்கியின்  பெயர் :</label>(optional)
<input   type="text" name="A_name" value=""   class="form-control phone" autocomplete="off" ></div>
  <div class="col-sm-4">
<label class="ex">வங்கிக் கிளை :</label>(optional)
<input   type="text" name="branch" value=""   class="form-control phone" autocomplete="off" ></div>
  <div class="col-sm-4">
<label class="ex">IFSC Code:</label>(optional)
<input   type="text" name="ifsc" value=""   class="form-control phone" autocomplete="off" ></div>
 <div class="col-sm-4">
<label class="ex">Account No:</label>(optional)
<input   type="text" name="a_no" value=""   class="form-control phone" autocomplete="off" ></div>
 <div class="col-sm-4">
<label class="ex">உங்கள் ஆதார் எண் :</label>
<input   type="text" name="Adhar_no" value="" minlength=12 maxlength="12"  class="form-control phone" autocomplete="off" required></div>
</div>
<div class="row">
 <div class="col-sm-10">
<label class="ex"><span>1.</span>படிக்கும்போதே பகுதி நேரமாக பணியாற்றிய அனுபவம் இதற்குமுன் உண்டா ?  </label> <label> <input type="radio" name="type" id="id~1" value="0" onclick="oncheckforyes(this)" required> ஆம் </label> /  <label> <input type="radio" name="type" id="id~1"  value="1" onclick="oncheckforyes(this)" required>இல்லை
</label></div></div>
<div class="row" id="idd1"  style="display:none">
 <div class="col-sm-6">
<label class="box" id="myDIV">‘ஆம்’ என்றால் அதுபற்றிய விவரம் சுருக்கமாக:
<div class="comment">
<textarea id="ans1"  width="50%"  name="ans1" class="form-control" ></textarea>
<span class="hint" id="textarea_message">
</label></div></div></div>
<div class="row">
<div class="col-sm-12">
<label class="ex" ><span>2.</span>பத்திரிகை / இணையதளத்தில் ஏதேனும் கதை /கவிதை /கட்டுரை எழுதிய அனுபவம் உண்டா ?</label> <label> <input type="radio" name="type1" id="id~2" value="0" onclick="oncheckforyes(this)" required> ஆம் </label> /  <label> <input type="radio" name="type1" id="id~2" value="1" onclick="oncheckforyes(this)" required>இல்லை
</label>
 </div></div>
 <div class="row" id="idd2" style="display:none">
 <div class="col-sm-6">
<label class="box">'ஆம்’ என்றால் அது பற்றிய விவரம்:
<div class="comment">
<textarea id="ans2"   width="50%" name="ans2" class="form-control"  ></textarea>
<span class="hint" id="textarea_message">
 </label></div></div></div>
<div class="row">
<div class="col-sm-12">
<label class="ex"><span>3.</span>பேச்சுப் போட்டி , கலை  நிகழ்ச்சி  உள்ளிட்ட மற்ற திறமைகளை வெளிப்படுத்தும் நிகழ்வுகளில் கலந்துகொண்ட அனுபவம் உண்டா ?  </label> <br><label> <input type="radio" name="type2" id="id~3" value="0" onclick="oncheckforyes(this)"> ஆம் </label> /  <label> <input type="radio" name="type2" id="id~3" value="1" onclick="oncheckforyes(this)" required>இல்லை
</label>
 </div></div> 
 <div class="row" id="idd3"  style="display:none">
 <div class="col-sm-6">
<label class="box">‘ஆம்’ எனில் அதுபற்றிய விவரம்: 
<div class="comment">
<textarea id="ans3" width="50%" name="ans3" class="form-control" ></textarea>
<span class="hint" id="textarea_message">
</label> </div></div></div>
<div class="row">
<div class="col-sm-12">
<label class="ex"><span>4.</span> உங்களின் காலை முதல் இரவு வரையிலான அன்றாடப் பணிகளை சுருக்கமாக வரிசைப்படுத்துங்கள்:</label>
<div class="comment">
<textarea  name="ans7" width="50%" class="form-control" required ></textarea>
<span class="hint" id="textarea_message">
 </div></div></div>
<div class="row">
 <div class="col-sm-10">
<label class="ex"><span>5.</span>நீங்கள் சொந்தமாக  வாகனம் வைத்திருக்கிறீர்களா?</label> <label> <input type="radio"  name="type3" id="id~4" value="0" onclick="oncheckforyes(this)" required> ஆம் </label> /  <label> <input type="radio" name="type3" id="id~4" value="1" onclick="oncheckforyes(this)" required>இல்லை
</label>
 </div></div> 
 <div class="row" id="idd4" style="display:none">
 <div class="col-sm-6">
<label class="box">‘ஆம்’ எனில், வாகன எண்/ உங்கள் ஓட்டுநர் உரிம எண் : 
<div class="comment">
<textarea id="ans4"  width="50%" name="ans4" class="form-control" ></textarea>
<span class="hint" id="textarea_message">
 </label></div></div></div>
 <div class="row">
 <div class="col-sm-12">
<label class="ex"><span>6.</span>உங்கள் குடும்பத்தில் அரசியல் கட்சி உறுப்பினர் எவரும் உண்டா ? :<label> <input type="radio" name="type4" id="id~5" value="0" onclick="oncheckforyes(this)" required> ஆம் </label> /  <label> <input type="radio" name="type4" id="id~5" value="1" onclick="oncheckforyes(this)" required>இல்லை
</label>
 </div></div>
 <div class="row" id="idd5"  style="display:none">
 <div class="col-sm-6">
<label class="box">‘ஆம்’ எனில் விவரம் :
<div class="comment">
<textarea id="ans5"  width="50%"   name="ans5" class="form-control"  ></textarea>
<span class="hint" id="textarea_message">
 </label></div></div></div>
<div class="row">
 <div class="col-sm-10">
<label class="ex"><span>7.</span>உங்கள் உறவினர் எவரும் பத்திரிகைத் துறையில் பணிபுரிகிறார்களா?: </label>  <label> <input type="radio" name="type5" id="id~6" value="0" onclick="oncheckforyes(this)" required> ஆம் </label> /  <label> <input type="radio" name="type5" id="id~6" value="1" onclick="oncheckforyes(this)" required>இல்லை
</label>
 </div></div>
 <div class="row" id="idd6"  style="display:none">
 <div class="col-sm-6" >
<label class="box">‘ஆம்’ எனில் விவரம்: 
<div class="comment">
<textarea id="ans6"     name="ans6" class="form-control" ></textarea>
<span class="hint" id="textarea_message">
 </label></div>
</div>
</div><hr>
 <div class="row">
 <div class="col-sm-12">
<label><font color="blue">கல்லூரி நிர்வாகத்தின் ஒப்புதல்: </font>கீழ்கண்டவாறு உங்கள் கல்லூரி முதல்வர் / தாளாளர் கையொப்பமும்  , கல்லூரியின்
முத்திரையும் கூடிய ஒப்புதல் கடிதம் பெறவேண்டியது அவசியம். நீங்கள் ஜூலை-21 அன்று நடை பெறும் எழுத்துத் தேர்வுக்கு
தேர்ந்தெடுக்கப்பட்டால் அந்த கடிதத்தை கட்டாயம் கொண்டுவரவும் .</label>
<label>எங்கள் கல்லூரியில் __________________________________________________ வகுப்பு  _____________________________________ ஆண்டு பயிலும் 
மாணவர் செல்வன் / செல்வி  ______________________________________________‘இந்து தமிழ் திசை ’ நாளிதழ் அளிக்கும் இந்தத் திட்டத்தின் கீழ், கல்லூரிப்
   படிப்பைத் தொடர்ந்து கொண்டே பகுதி நேரமாகப் பயிற்சி
பெறுவதில், எந்த ஆட்சேபணையும் இல்லை.</label><br><br><br><label>
கல்லூரி முதல்வர்/ தாளாளர் கையொப்பம்    (முத்திரையுடன்): ___________________________________________________________________________</label><br><br><br>

<label><font color="red"><center>எழுத்துத் தேர்வுக்கு தேர்ந்தெடுக்கப்பட்டால் உங்கள் மார்பளவு பாஸ்போர்ட் சைஸ் புகைப்படங்கள் இரண்டு மற்றும் விண்ணப்ப படிவத்தின் நகலை தவறாமல் கொண்டுவரவும்.<br>கல்லூரி நிர்வாகத்தின் ஒப்புதல் பெறப்பட்ட விண்ணப்ப படிவம் மட்டுமே தேர்வுசெய்யப்படும்.</center></font></div></div>
 </fieldset>
 </div>
 </div>
 <div id="footer">
<div class="alert alert-success">
 
     <center><div class="row">
       <button type="reset" name="reset" value="Reset" class="btn btn-warning btn-lg">Reset</button>&nbsp;&nbsp;&nbsp;
	   <button type="submit"  name="submit" href="pdf.php"   class="btn btn-success btn-lg">Submit</button> 
    </div> </center>  
   </div>
   </div>
  </form>
 </div>
 </div>
 </div>
 
<script>
var doc=$("#id1").value;
var doc1=$("#id2").value;
var doc2=$("#id3").value;
var doc3=$("#id4").value;
var doc4=$("#id5").value;
var doc5=$("#id6").value;
function oncheckforyes(value1){
	var p=value1;
	 
	var c=p.id;
var split=c.split('~');

if(p.value=='0'){

document.getElementById(split[0]+'d'+split[1]).style.display='block';	
document.getElementById("ans"+split[1]).required=true;
	
}
else if(p.value=='1'){
	
	document.getElementById(split[0]+'d'+split[1]).style.display='none';
	document.getElementById("ans"+split[1]).required=false;
}

}

</script>
  </body>
  </html>
  <?php
if(isset($_POST["submit"]))
{
	 
	$name=$_POST['name'];
	$lan=$_POST['lang'];
	$fname=$_POST['fname'];
	$fwork=$_POST['fwork'];
	$dob=$_POST['dob'];
	$address=$_POST['address'];
	$dis=$_POST['dis'];
	$pincode=$_POST['pincode'];
	$mobile=$_POST['tel_num'];
	$email=$_POST['email'];
	$cname=$_POST['c_name'];
	$caddress=$_POST['c_address'];
	$cpin=$_POST['c_pincode'];
	$dep=$_POST['dep'];
	$year=$_POST['year'];
	$bank_name=$_POST['A_name'];
	$branch=$_POST['branch'];
	$A_no=$_POST['a_no'];
	$ifsc=$_POST['ifsc'];
	$Adhar=$_POST['Adhar_no'];
	$type=$_POST['type'];
	$ans1=$_POST['ans1'];
	$type1=$_POST['type1'];
	$ans2=$_POST['ans2'];
	$type2=$_POST['type2'];
	$ans3=$_POST['ans3'];
	$ans4=$_POST['ans7'];
	$type3=$_POST['type3'];
	$ans5=$_POST['ans4'];
	$type4=$_POST['type4'];
	$ans6=$_POST['ans5'];
	$type5=$_POST['type5'];
	$ans7=$_POST['ans6'];
	 
	
 $sql1="select count(*) as Count from studend_sales_rep.student_rep_details_ht";
 $result=$con->query($sql1);
  $res1=$result->fetch_assoc();
 if($res1['Count']==0){
	 $appval="SSRCIR40000";
 }
 else if($res1['Count']>0){
 $sql2="select id from studend_sales_rep.student_rep_details_ht order by id desc";
 $result1=$con->query($sql2);
$res2=$result1->fetch_assoc();
 $p=(int)($res2['id'])+1;
 echo $appval='SSRCIR4000'.$p;
 
 }
 
 
	 
	 
$sql="INSERT INTO studend_sales_rep.student_rep_details_ht (Application_id,std_name,Language,Father_name,Father_occupattion,DOB,Address,District,pincode,mobile,email,College_name,college_Address,college_pincode,Stud_dep,student_year,Bank_name,Account_no,Branch,IFSC_code,Adhar_id,question_1,Answer_1,Qustion_2,Answer_2,Question_3,Answer_3,Answer_4,Question_5,Answer_5,Question_6,Answer_6,Question_7,Answer_7) VALUES('$appval','$name','$lan','$fname','$fwork','$dob','$address','$dis','$pincode','$mobile','$email','$cname','$caddress','$cpin','$dep','$year','$bank_name','$branch','$A_no','$ifsc','$Adhar','$type','$ans1','$type1','$ans2','$type2','$ans3','$ans4','$type3','$ans5','$type4','$ans6','$type5','$ans7')";
 
echo $sql;
if ($con->query($sql) === TRUE) {
	$id=mysqli_insert_id($con);
	 echo "<script>
  alert('Submitted successfully');
  window.location.href='pdf.php?id=".$id."';
  </script>";
} else {
  echo "Error: " . $sql . "<br>" . $con->error;
}
 
}
?>