<?php
$con = new mysqli("dbusername","root","dbpass","studend_sales_rep");
?>
 