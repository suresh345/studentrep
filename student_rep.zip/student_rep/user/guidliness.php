<table border="1">
 <button onclick="myFunction()" class="btn btn-info">Guidelines..!</button> 
 <div id="myDIV">
 <ol>
<b><li>Type your text in the textbox, using Spacebar or Tab button would change the text to Tamil language. </li>
<li>Position the mouse on the Tamil word and you will have option of words to choose from, including English. </li>
<li>Fill the data carefully, once submitted, the data it cannot be edited. </li>
<li>Mobile user, please  use Tamil  keyboard</b>
  </ol></div></table>