<br/>
</div>
</div>
<div id="footer">
<div class="alert alert-success">
 
     <center><div class="row">
       <button type="reset" name="reset" value="Reset" class="btn btn-warning btn-lg">Reset</button>&nbsp;&nbsp;&nbsp;
	   <button type="submit"  name="submit" onclick="this.form.submit();this.disabled = true;" class="btn btn-success btn-lg">Submit</button> 
    </div> </center>
   </div>
   </div>
</form>
</body>
 </html>  