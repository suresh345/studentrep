<?php
include "config.php";
?>
 <?php

header('Content-Type: text/html;charset=utf-8'); ?>
<!DOCTYPE html>
<html lang="ta">

<head>
  <title>Student Sales Rep</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <!-- Optional theme -->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-theme.min.css">
 <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
   <link rel="stylesheet" href="css/s.css"> 
   <link rel="stylesheet" type="text/css" href="css/1.css" media="screen">
<script type="text/javascript" src="css/jso.js" language="javascript"></script>
<link href="https://fonts.googleapis.com/css?family=Catamaran|Kavivanar" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js">  
</script>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html"; charset="utf-8" />
<script type="text/javascript" src="http://www.google.com/jsapi"></script>
   <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script type="text/javascript">

  // Load the Google Transliteration API
  google.load("elements", "1", {
    packages: "transliteration"
  });

  function onLoad() {
    var options = {
      sourceLanguage: 'en',
      destinationLanguage: 'ta',
      shortcutKey: 'ctrl+m',
      transliterationEnabled: true
    };

    // Create an instance on TransliterationControl with the required
    var control = new google.elements.transliteration.TransliterationControl(options);

    // Enable transliteration in the textfields with the given elements.
    var elements = document.getElementsByClassName('form-control');
control.makeTransliteratable(elements);

    // Show the transliteration control which can be used to toggle between
    // English and Hindi and also choose other destination language.
   
  }
  google.setOnLoadCallback(onLoad);
</script>
</head>  
 
<body>

<center>
 <div class="header">
  <div class="alert alert-success" style="margin-bottom: 10px;padding-bottom: 0px;">
     <center><img src="https://tamil.thehindu.com/static/theme/default/base/img/newIpadLogo.png" height="50%" border="0"  class="responsive"></center>
  </div>
  </div>
</center>